from flask import Flask, render_template, request, redirect, url_for
from models.user import User
from models.honeymoon_package import HoneymoonPackage
from models.family_package import FamilyPackage
from models.accommodation import Accommodation
from models.activity import Activity
from models.booking import Booking
from extensions import db  # Import db from extensions.py

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///javentures.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize the db here
db.init_app(app)

# Dummy in-memory packages (not saved in DB for now)
packages = []

# Create some dummy packages
acc = Accommodation("Serena Hotel", 200)
packages.append(HoneymoonPackage("Romantic Uganda", 5, acc, [Activity("Spa", 50), Activity("Boat Cruise", 70)]))
packages.append(FamilyPackage("Family Fun", 4, acc, [Activity("Zoo", 30), Activity("Hiking", 20)]))

@app.route('/')
def index():
    return render_template('index.html', packages=packages)

@app.route('/package/<name>')
def package_details(name):
    package = next((p for p in packages if p.name == name), None)
    return render_template('package_details.html', package=package)

@app.route('/book', methods=['GET', 'POST'])
def create_booking():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        start_date = request.form['start_date']
        pkg_name = request.form['package_name']

        # Create new booking using the correct constructor
        new_booking = Booking(username=username, email=email, start_date=start_date, package_name=pkg_name)
        db.session.add(new_booking)
        db.session.commit()

        return redirect(url_for('index'))

    return render_template('create_booking.html', packages=packages)

@app.route('/booking')
def view_bookings():
    all_bookings = Booking.query.all()
    return render_template('bookings.html', bookings=all_bookings)

# Ensure all database tables are created before running the app
if __name__ == '__main__':
    with app.app_context():
        db.create_all() 
    app.run(debug=True)
