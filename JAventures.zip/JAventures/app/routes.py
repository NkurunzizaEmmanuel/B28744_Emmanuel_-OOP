
from flask import Blueprint, render_template, request, redirect, url_for, session
from models import User, VacationPackage, CustomPackage

main = Blueprint('main', __name__)

users = {}
packages = [
    VacationPackage('Romantic Nile Escape', 'honeymoon', 100),
    VacationPackage('Family Safari Adventure', 'family', 80)
]

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/packages')
def browse_packages():
    return render_template('packages.html', packages=packages)

@main.route('/book', methods=['GET', 'POST'])
def book():
    if request.method == 'POST':
        name = request.form['name']
        nights = int(request.form['nights'])
        category = request.form['category']
        transport = int(request.form.get('transport', 0))
        activities = int(request.form.get('activities', 0))

        custom = CustomPackage(name, category, 100, transport, activities)
        total = custom.calculate_cost(nights)

        return f"You booked {name} for {nights} nights. Total cost: ${total}"
    return render_template('book.html')
