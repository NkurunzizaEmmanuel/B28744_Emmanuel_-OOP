from werkzeug.security import generate_password_hash, check_password_hash

# User base class
class User:
    def __init__(self, username, email, password, is_admin=False):
        self.username = username
        self.email = email
        self.password_hash = generate_password_hash(password)
        self.is_admin = is_admin

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


# Package base class
class VacationPackage:
    def __init__(self, name, category, price_per_night):
        self.name = name
        self.category = category  # e.g., 'honeymoon' or 'family'
        self.price_per_night = price_per_night

    def calculate_cost(self, nights):
        return self.price_per_night * nights


# Customized Package (Inheritance and Polymorphism)
class CustomPackage(VacationPackage):
    def __init__(self, name, category, price_per_night, transport_fee=0, activity_fee=0):
        super().__init__(name, category, price_per_night)
        self.transport_fee = transport_fee
        self.activity_fee = activity_fee

    def calculate_cost(self, nights):
        base = super().calculate_cost(nights)
        return base + self.transport_fee + self.activity_fee
