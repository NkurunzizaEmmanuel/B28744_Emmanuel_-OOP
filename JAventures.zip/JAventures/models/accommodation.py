class Accommodation:
    def __init__(self, name, price_per_night):
        self.name = name
        self.price_per_night = price_per_night

    def get_details(self):
        return f"{self.name}: ${self.price_per_night} per night"


