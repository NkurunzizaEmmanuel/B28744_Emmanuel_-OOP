
# models/package.py

from abc import ABC, abstractmethod

class Package(ABC):
    def __init__(self, name, duration, base_price):
        self.name = name
        self.duration = duration
        self.base_price = base_price
        self.activities = []

    def add_activity(self, activity):
        self.activities.append(activity)

    @abstractmethod
    def get_total_price(self):
        pass

    def get_details(self):
        return {
            "name": self.name,
            "duration": self.duration,
            "base_price": self.base_price,
            "activities": [activity.name for activity in self.activities]
        }
    def get_description(self):
        return f"{self.name} package for {self.duration} days."
