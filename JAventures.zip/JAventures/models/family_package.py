# models/family_package.py

from .package import Package

class FamilyPackage(Package):
    def __init__(self, name, duration, accommodation, activities=[]):
        super().__init__(name, duration, base_price=250)
        self.accommodation = accommodation
        self.activities = activities
      

    def get_total_price(self):
        total = self.base_price
        total += self.accommodation.price_per_night * self.duration
        for activity in self.activities:
            total += activity.price
        return total
    def get_description(self):
        return f"{self.name} - {self.duration} days, family-friendly adventure with {len(self.activities)} activities."

    def calculate_cost(self):
        return self.get_total_price()
