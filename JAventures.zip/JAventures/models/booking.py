# models/booking.py
from extensions import db  # Import db from extensions.py

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    start_date = db.Column(db.String(20), nullable=False)
    package_name = db.Column(db.String(100), nullable=False)

    def __init__(self, username, email, start_date, package_name):
        self.username = username
        self.email = email
        self.start_date = start_date
        self.package_name = package_name







