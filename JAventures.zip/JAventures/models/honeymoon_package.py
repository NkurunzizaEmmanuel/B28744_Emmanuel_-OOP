# models/honeymoon_package.py
from .package import Package

class HoneymoonPackage(Package):
    def __init__(self, name, duration, accommodation, activities=[]):
        base_price = 300  # You can change this default if needed
        super().__init__(name=name, duration=duration, base_price=base_price)
        self.accommodation = accommodation
        self.activities = activities

    def get_total_price(self):
        total = self.base_price
        total += self.accommodation.price_per_night * self.duration
        for activity in self.activities:
            total += activity.price
        return total

    def calculate_cost(self):
        return self.get_total_price()

    def get_description(self):
        return f"{self.name} - {self.duration} days, romantic experience with {len(self.activities)} activities."
